#include<bits/stdc++.h>
using namespace std;
void le_entrada();
void inicializa_grafo();
void adiciona_no_grafo(int x, int y);
bool eh_clique(vector<int> vet);
void libera();