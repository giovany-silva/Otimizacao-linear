import os

#os.system("python3 Meu_Resolvedor_Python.py ./data/tsp_51_1 ./sols/tsp_51_1.sol")
#os.system("python3 Meu_Resolvedor_Python.py ./data/tsp_100_3 ./sols/tsp_100_3.sol")
#os.system("python3 Meu_Resolvedor_Python.py ./data/tsp_200_2 ./sols/tsp_200_2.sol")
#os.system("python3 Meu_Resolvedor_Python.py ./data/tsp_574_1 ./sols/tsp_574_1.sol")
#os.system("python3 Meu_Resolvedor_Python.py ./data/tsp_1889_1 ./sols/tsp_1889_1.sol")
#os.system("python3 Meu_Resolvedor_Python.py ./data/tsp_33810_1 ./sols/tsp_33810_1.sol")


#Depois de compilar o resolvedor em c++ com "g++ Meu_Resolvedor_C++.cpp -o Meu_Resolvedor_C++" voce pode testar os comandos abaixo
os.system("./Meu_Resolvedor_C++ ./data/tsp_51_1 ./sols/tsp_51_1.sol")
os.system("./Meu_Resolvedor_C++ ./data/tsp_100_3 ./sols/tsp_100_3.sol")
os.system("./Meu_Resolvedor_C++ ./data/tsp_200_2 ./sols/tsp_200_2.sol")
os.system("./Meu_Resolvedor_C++ ./data/tsp_574_1 ./sols/tsp_574_1.sol")
os.system("./Meu_Resolvedor_C++ ./data/tsp_1889_1 ./sols/tsp_1889_1.sol")
os.system("./Meu_Resolvedor_C++ ./data/tsp_33810_1 ./sols/tsp_33810_1.sol")
