import os


os.system("cd ./sols/; echo '../data/tsp_51_1 0' | python3 verifier.py")
os.system("cd ./sols/; echo '../data/tsp_51_1 1' | python3 verifier.py")
os.system("cd ./sols/; echo '../data/tsp_51_1 2' | python3 verifier.py")
print()

os.system("cd ./sols/; echo '../data/tsp_100_3 0' | python3 verifier.py")
os.system("cd ./sols/; echo '../data/tsp_100_3 1' | python3 verifier.py")
os.system("cd ./sols/; echo '../data/tsp_100_3 2' | python3 verifier.py")
print()

os.system("cd ./sols/; echo '../data/tsp_200_2 0' | python3 verifier.py")
os.system("cd ./sols/; echo '../data/tsp_200_2 1' | python3 verifier.py")
os.system("cd ./sols/; echo '../data/tsp_200_2 2' | python3 verifier.py")
print()

os.system("cd ./sols/; echo '../data/tsp_574_1 0' | python3 verifier.py")
os.system("cd ./sols/; echo '../data/tsp_574_1 1' | python3 verifier.py")
os.system("cd ./sols/; echo '../data/tsp_574_1 2' | python3 verifier.py")
print()

os.system("cd ./sols/; echo '../data/tsp_1889_1 0' | python3 verifier.py")
os.system("cd ./sols/; echo '../data/tsp_1889_1 1' | python3 verifier.py")
os.system("cd ./sols/; echo '../data/tsp_1889_1 2' | python3 verifier.py")
print()

os.system("cd ./sols/; echo '../data/tsp_33810_1 0' | python3 verifier.py")
os.system("cd ./sols/; echo '../data/tsp_33810_1 1' | python3 verifier.py")
os.system("cd ./sols/; echo '../data/tsp_33810_1 2' | python3 verifier.py")
print()


