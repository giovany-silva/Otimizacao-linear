instalar o graphviz:
sudo apt-get update
sudo apt-get install graphviz
instalar o allegro 5:
sudo apt-get update
sudo apt-get install liballegro5.0

Compilar com makefile
executar ./greedy_firefighter <nome_da_instância



