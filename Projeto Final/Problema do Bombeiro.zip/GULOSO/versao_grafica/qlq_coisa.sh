gcc loadImage.c -o loadImage -lalleg  -I/home/monstruosoft/libs/usr/local/include/ -L/home/monstruosoft/libs/usr/local/lib/ -lallegro -lallegro_primitives -lallegro_image -load_bitmap_at_size&& ./loadImage

